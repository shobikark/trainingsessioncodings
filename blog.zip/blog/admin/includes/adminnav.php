<nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
	<div class="container-fluid">
		<div class="navbar-header">
			<a class="navbar-brand" href="index.php">CMS ADMIN</a>
		</div>
		<ul class="nav navbar-nav">
			<li><a href="index.php">Dashboard</a></li>
			<li>
				<a href="javascript:;" class="dropdown-toggle" data-toggle="collapse" data-target="#posts"><i class="fa fa-fw fa-file-text"></i> Posts <i class="fa fa-fw fa-caret-down"></i></a>
				<ul id="posts" class="collapse">
					<li><a href="./posts.php">View All Posts</a></li>
					<li><a href="./publishnews.php">Add New Post</a></li>
				</ul>
			</li>
			<li>
				<a href="javascript:;" data-toggle="collapse" data-target="#user"><i class="fa fa-fw fa-users"></i> Users <i class="fa fa-fw fa-caret-down"></i></a>
				<ul id="user" class="collapse">
					<li><a href="./users.php">View All Users</a></li>
					<li><a href="adduser.php">Add New User</a></li>
				</ul>
			</li>
		</ul>
		<ul class="nav navbar-nav navbar-right">
		  <li><a href="../logout.php"><span class="glyphicon glyphicon-log-out"></span> Logout</a></li>
		</ul>
	</div>
</nav>