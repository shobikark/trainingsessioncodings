<footer class="foo">
	<div class="col-lg-12">
		<p style="text-align:center; font-size:21px; color: #fff; background-color: #092247; padding: 40px;"><b>Copyrights Infiniti Software Solutions</b></p>
	</div>   
</footer>
