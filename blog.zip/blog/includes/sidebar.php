<div class="well">
	<h4 class="text-primary text-center"><b>SIGN-IN</b></h4>
	<form method="POST" action="login.php">
		<div class="">
			<input name="user_name" type="text" class="form-control" placeholder="Enter Username" required>
		</div>
		<br>
		<div class="">
			<input name="user_password" type="password" class="form-control" placeholder="Enter Passsword" required>
		</div>
		<br>
		<span class="input-group-btn">
			<center> 
				<button name="login" class="btn btn-primary" type="submit">LOGIN</button>
			</center>
		</span>
		</div>
	</form>
</div>


